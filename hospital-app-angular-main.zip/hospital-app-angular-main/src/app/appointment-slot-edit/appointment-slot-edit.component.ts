import { Component } from '@angular/core';

@Component({
  selector: 'app-appointment-slot-edit',
  templateUrl: './appointment-slot-edit.component.html',
  styleUrls: ['./appointment-slot-edit.component.css']
})
export class AppointmentSlotEditComponent {

}
