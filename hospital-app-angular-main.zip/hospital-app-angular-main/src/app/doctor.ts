export class Doctor {
    id: number=0;
    name: string="";
    specialization: string="";
    contactInformation: string="";

    constructor(){}
  }
  