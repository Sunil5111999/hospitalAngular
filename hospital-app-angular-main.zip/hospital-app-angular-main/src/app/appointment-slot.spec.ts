import { AppointmentSlot } from './appointment-slot';

describe('AppointmentSlot', () => {
  it('should create an instance', () => {
    expect(new AppointmentSlot()).toBeTruthy();
  });
});
