import { MedicalRecord } from './medical-record';

describe('MedicalRecord', () => {
  it('should create an instance', () => {
    expect(new MedicalRecord()).toBeTruthy();
  });
});
