import { Billing } from './billing';

describe('Billing', () => {
  it('should create an instance', () => {
    expect(new Billing()).toBeTruthy();
  });
});
