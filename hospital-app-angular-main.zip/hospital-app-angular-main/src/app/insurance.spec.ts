import { Insurance } from './insurance';

describe('Insurance', () => {
  it('should create an instance', () => {
    expect(new Insurance()).toBeTruthy();
  });
});
